﻿
using Microsoft.AspNetCore.Identity;

namespace Project2API.Authentication
{
    public class ApplicationUser : IdentityUser
    {
    }
}

